# RFSOC-AMC
AMC module with Xilinx RF-SoC and two analog front-end mezzanines for SDR and quantum applications

## Design Files

Design files (schematics, PCB layouts, BOMs) can be found at [RFSOC-AMC/Releases](https://github.com/sinara-hw/RFSOC-AMC/releases).

## Wiki

More information can be found on the [wiki](https://github.com/sinara-hw/RFSOC-AMC/wiki).
