/*
 * (c) 2007 Stanislaw K Skowronek
 * Licensed under the terms of GPLv2 or later
 */

#undef DEBUG

#include <stdio.h>
#include <malloc.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <ftdi.h>

#define MAX_IR 512
#define MAX_DEV 80

// SVF parser parameters
#define CHUNK 4096
#define NWORDS 16

// JTAG TAP states
#define RESET 0
#define IDLE 1
#define DRPAUSE 2
#define DRSHIFT 3
#define IRSHIFT 4
char *states[]={"RESET", "IDLE", "DRPAUSE", "DRSHIFT", "IRSHIFT", NULL};

struct ftdi_context ctx;

int total_ir;
int ndev;
int total_bsc;
int bypass[MAX_DEV];
char *name[MAX_DEV];
int irlen[MAX_DEV];
uint32_t sample[MAX_DEV];
uint32_t extest[MAX_DEV];
int bslen[MAX_DEV];
char **bsname[MAX_DEV];
char *bsmode[MAX_DEV];
int *bszpin[MAX_DEV];
int *bszval[MAX_DEV];
int *bsextr[MAX_DEV];

int *bsc_in_global;
int *bsc_out_global;
int *bsc_in[MAX_DEV];
int *bsc_out[MAX_DEV];

int *bsc_clk[MAX_DEV];
int *bsc_tmp[MAX_DEV];
int *bsc_sig0[MAX_DEV];
int *bsc_sig1[MAX_DEV];

void setgpio(uint8_t val)
{
	uint8_t buf[3];
	buf[0] = SET_BITS_LOW;
	buf[1] = 0x08 | (val<<4);
	buf[2] = 0xDB;
	if(ftdi_write_data(&ctx, buf, 3)<0)
		fprintf(stderr, "write error\n");
}

void setspeed(uint16_t val)
{
	uint8_t buf[3];
	buf[0] = TCK_DIVISOR;
	buf[1] = val;
	buf[2] = val>>8;
	if(ftdi_write_data(&ctx, buf, 3)<0)
		fprintf(stderr, "write error\n");
}

uint8_t getstat(void)
{
	uint8_t res;
	if(ftdi_read_pins(&ctx, &res)<0)
		fprintf(stderr, "read error\n");
	return res;
}

char board_name[9];

int init(void)
{
	uint8_t latency;
	ftdi_init(&ctx);
	ftdi_set_interface(&ctx, INTERFACE_A);
	if(board_name[0]) {
		if(ftdi_usb_open_desc(&ctx, 0x8482, 0x1002, NULL, board_name))
			return 1;
	} else
		if(ftdi_usb_open(&ctx, 0x8482, 0x1002))
			return 1;
	ftdi_usb_reset(&ctx);
	ftdi_set_latency_timer(&ctx, 1);
	ftdi_get_latency_timer(&ctx, &latency);
	if(latency != 1)
		fprintf(stderr, "fail latency set\n");
	if(ftdi_set_bitmode(&ctx, 0x0B, BITMODE_MPSSE))
		return 1;
	ftdi_usb_purge_buffers(&ctx);
	setgpio(9);
	setspeed(1);
	return 0;
}

void done(void)
{
	setgpio(5);
	ftdi_usb_close(&ctx);
	ftdi_deinit(&ctx);
}

uint8_t last;
void clock(int tms, int tdi)
{
	uint8_t buf[3];
	int r, t=0;
	buf[0] = MPSSE_WRITE_TMS|MPSSE_DO_READ|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
	buf[1] = 0x00;
	buf[2] = (tdi<<7)|tms;
	if(ftdi_write_data(&ctx, buf, 3)<0)
		fprintf(stderr, "write error\n");
	do {
		if((r=ftdi_read_data(&ctx, buf, 1))<0)
			fprintf(stderr, "read error\n");
		if(t>5) {
			fprintf(stderr, "read timeout\n");
			break;
		}
		t++;
	} while(r!=1);
	last = buf[0]>>7;
}

int gettdo(void)
{
	return last;
}

uint32_t shifti(uint32_t v, int l, int t)
{
	uint8_t buf[16];
	uint32_t p=0, i, ol = l, ib = 0, to = 0, r;
	// prepare and send TDO/TMS message
	if((l-t)>=8) {
		buf[0] = MPSSE_DO_WRITE|MPSSE_DO_READ|MPSSE_LSB|MPSSE_WRITE_NEG;
		buf[1] = ((l-t)/8)-1;
		buf[2] = 0x00;
		p = 3;
		for(i=0;i<=buf[1];i++) {
			buf[p] = v;
			v >>= 8;
			l -= 8;
			p++;
			ib++;
		}
	}
	if((l-t)>=1) {
		buf[p] = MPSSE_DO_WRITE|MPSSE_DO_READ|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = l-t-1;
		buf[p+2] = v;
		v >>= l-t;
		l = t;
		p += 3;
		ib++;
	}
	if(l) {
		buf[p] = MPSSE_WRITE_TMS|MPSSE_DO_READ|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = 0x00;
		buf[p+2] = (v<<7)|1;
		p += 3;
		ib++;
	}
	if(ftdi_write_data(&ctx, buf, p)<0)
		fprintf(stderr, "write error\n");
	// read and unpack TDI message
	p = 0;
	do {
		if((r=ftdi_read_data(&ctx, buf+p, ib-p))<0) {
			fprintf(stderr, "read error\n");
			return 0;
		}
		p += r;
		if(to>5) {
			fprintf(stderr, "read timeout\n");
			return 0;
		}
		to++;
	} while(p<ib);
	p = 0;
	l = ol;
	r = 0;
	while((l-t)>=8) {
		r |= buf[p] << (p*8);
		l -= 8;
		p++;
	}
	if((l-t) >= 1) {
		r |= (buf[p]>>(8-(l-t))) << (p*8);
		p++;
	}
	if(t)
		r |= (buf[p]>>7) << (ol-1);
	return r;
}

void int_shiftr(uint32_t state, int *out, int *in, int l, int t)
{
	uint8_t buf[8192], fl=in?MPSSE_DO_READ:0;
	uint32_t p=0, i, ol = l, ib = 0, to = 0, r, vp = 0, j, a, vl;
	// prepare and send TDO/TMS message
	if(state) {
		buf[p++] = MPSSE_WRITE_TMS|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p++] = (state>>8)-1;
		buf[p++] = state;
	}
	if((l-t)>=8) {
		buf[p++] = MPSSE_DO_WRITE|fl|MPSSE_LSB|MPSSE_WRITE_NEG;
		vl = ((l-t)/8)-1;
		buf[p++] = vl;
		buf[p++] = vl>>8;
		for(i=0;i<=vl;i++) {
			a = 0;
			for(j=0;j<8;j++)
				a |= (out[vp+j])<<j;
			buf[p] = a;
			vp += 8;
			l -= 8;
			p++;
			ib++;
		}
	}
	if((l-t)>=1) {
		buf[p] = MPSSE_DO_WRITE|fl|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = l-t-1;
		a = 0;
		for(j=0;j<l-t;j++)
			a |= (out[vp+j])<<j;
		buf[p+2] = a;
		vp += l-t;
		l = t;
		p += 3;
		ib++;
	}
	if(l) {
		buf[p] = MPSSE_WRITE_TMS|fl|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = 0x05;
		buf[p+2] = (out[vp]<<7)|0x03;
		p += 3;
		ib++;
	}
	if(in)
		buf[p++] = SEND_IMMEDIATE;
	if(ftdi_write_data(&ctx, buf, p)<0)
		fprintf(stderr, "write error (%s)\n", ftdi_get_error_string(&ctx));
	// skip if nothing to be read
	if(!in)
		return;
	// read and unpack TDI message
	p = 0;
	do {
		if((r=ftdi_read_data(&ctx, buf+p, ib-p))<0) {
			fprintf(stderr, "read error\n");
			return;
		}
		p += r;
		if(to>10) {
			fprintf(stderr, "read timeout\n");
			return;
		}
		to++;
	} while(p<ib);
	p = 0;
	l = ol;
	vp = 0;
	while((l-t)>=8) {
		for(j=0;j<8;j++)
			in[vp+j] = (buf[p]>>j)&1;
		vp += 8;
		l -= 8;
		p++;
	}
	if((l-t) >= 1) {
		for(j=0;j<l-t;j++)
			in[vp+j] = (buf[p]>>(j+8-(l-t)))&1;
		vp += l-t;
		p++;
	}
	if(t)
		in[vp] = buf[p]>>7;
}

#define MAXBITS 1024
void shiftr(uint32_t state, int *out, int *in, int l, int t)
{
	int p=0, b;
	while(l>0) {
		b=l;
		if(b>MAXBITS)
			b=MAXBITS;
		int_shiftr(state, out+p, in?in+p:NULL, b, (b==l)?t:0);
		l-=b;
		p+=b;
		state=0;
	}
}

void statewalk(uint8_t tms, int l, int tdi)
{
	uint8_t buf[3];
	buf[0] = MPSSE_WRITE_TMS|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
	buf[1] = l-1;
	buf[2] = (tdi<<7)|tms;
	if(ftdi_write_data(&ctx, buf, 3)<0)
		fprintf(stderr, "write error\n");
}

void reset(void)
{
	statewalk(0x1F, 5, 0);
}

void cap_dr(void)
{
	statewalk(0x02, 3, 0);
}

void cap_ir(void)
{
	statewalk(0x06, 4, 0);
}

int regsize(int max)
{
	int i;
	int *r1 = malloc(max*sizeof(int));
	int *r2 = malloc(max*sizeof(int));
	for(i=0;i<max;i++)
		r1[i] = 0xFFFFFFFF;
	clock(0,0);
	shiftr(0, r1, r2, max, 0);
	clock(0,0);
	shiftr(0, r1, r2, max, 0);
	statewalk(0x03, 3, 1);
	for(i=0;i<max;i++) {
		if(!r2[i]) {
			free(r1);
			free(r2);
			return i+1;
		}
	}
	reset();
	free(r1);
	free(r2);
	return -1;
}

int size_chain(void)
{
	cap_ir();
	total_ir=regsize(MAX_IR);
	if(total_ir==-1)
		return 1;
	cap_dr();
	ndev=regsize(MAX_DEV);
	if(ndev==-1)
		return 1;
	return 0;
}

void loadinfo(int i, uint32_t b)
{
	char fname[32];
	char line[256], *p, *q;
	int idx;
	FILE *f;
	if(b!=0)
	    sprintf(fname, "dev/%08X", b);
	else
	    sprintf(fname, "local/%d", i);
	f=fopen(fname,"r");
	if(!f) {
		name[i]=NULL;
		return;
	}
	bypass[i]=7;
	while(fgets(line, 256, f)) {
		p=strpbrk(line, "\n\r");
		if(p)
			*p=0;
		p=strpbrk(line, "\t ");
		if(!p) {
			fprintf(stderr, "%s: malformed line '%s'\n", fname, line);
			name[i]=NULL;
			return;
		}
		*p=0;
		p++;
		while(*p=='\t' || *p==' ')
			p++;
		if(!strcmp(line,"name")) {
			name[i]=strdup(p);
		} else if(!strcmp(line,"irsize")) {
			irlen[i]=strtol(p,NULL,0);
		} else if(!strcmp(line,"sample")) {
			sample[i]=strtol(p,NULL,2);
			bypass[i]&=~1;
		} else if(!strcmp(line,"extest")) {
			extest[i]=strtol(p,NULL,2);
			bypass[i]&=~2;
		} else if(!strcmp(line,"bssize")) {
			bslen[i]=strtol(p,NULL,0);
			bypass[i]&=~4;
			bsname[i]=calloc(sizeof(char *), bslen[i]);
			bsmode[i]=calloc(sizeof(char), bslen[i]);
			bszpin[i]=calloc(sizeof(int), bslen[i]);
			bszval[i]=calloc(sizeof(int), bslen[i]);
			bsextr[i]=calloc(sizeof(int), bslen[i]);
		} else if(!strncmp(line,"bsc[",4) || !strncmp(line,"ext[",4)) {
			idx=strtol(line+4,&q,0);
			if(!q || *q!=']' || idx<0 || idx>bslen[i]) {
				fprintf(stderr, "%s: bad index in '%s'\n", fname, line);
				name[i]=NULL;
				return;
			}
			q=strchr(p,' ');
			*(q++)=0;
			if(!strncmp(line,"ext[",4))
				bsextr[i][idx]=1;
			bsname[i][idx]=strdup(p);
			bsmode[i][idx]=*q;
			if(*q=='Z' || *q=='Y') {
				bszval[i][idx]=q[1]-'0';
				bszpin[i][idx]=strtol(q+3, &p, 0);
				if(!p || *p) {
					fprintf(stderr, "%s: bad tristate pin in '%s'\n", fname, line);
					name[i]=NULL;
					return;
				}
			}
		} else {
			fprintf(stderr, "%s: unknown field '%s'\n", fname, line);
			name[i]=NULL;
			return;
		}
	}
	fclose(f);
}

int idcodes(void)
{
	int i,fail=0,irsum=0,alt=0;
	uint32_t b;
	reset();
	statewalk(0x02, 4, 0); // cap_dr + '0'
	for(i=0;i<ndev;i++) {
		clock(0,alt);
		alt^=1;
		b=gettdo();
		if(b)
			b|=shifti(0x55555555<<alt, 31, 0)<<1;
		loadinfo(i, 0);
		if(!name[i])
		    loadinfo(i, b);
		if(name[i]) {
#ifdef DEBUG
			fprintf(stderr, "Device %d: IDCODE %08X (%s)\n", i, b, name[i]);
#endif
			if(!irlen[i]) {
				fprintf(stderr, "  Missing IR length\n");
				fail=1;
			}
			if(bypass[i]) {
#ifdef DEBUG
				fprintf(stderr, "  Device is bypassed\n");
#endif
				total_bsc++;
			} else
				total_bsc += bslen[i];
			irsum+=irlen[i];
		} else {
			fprintf(stderr, "Device %d: IDCODE %08X (MANUF: %03X, PART: %04X, VER: %01X)\n", i, b, (b>>1)&0x3FF, (b>>12)&0xFFFF, (b>>28)&0xF);
			fail=1;
		}
	}
	b = 0;
	bsc_in_global=calloc(sizeof(int), total_bsc);
	bsc_out_global=calloc(sizeof(int), total_bsc);
	for(i=0;i<ndev;i++) {
		bsc_in[i]=bsc_in_global+b;
		bsc_out[i]=bsc_out_global+b;
		if(bypass[i])
			b++;
		else
			b += bslen[i];
	}
#ifdef DEBUG
	fprintf(stderr, "Total boundary scan chain: %d\n", total_bsc);
#endif
	statewalk(0x03, 3, 1);
	if(irsum!=total_ir) {
		fprintf(stderr, "Total IR length %d mismatches sum of device IR lengths %d\n", total_ir, irsum);
		fail=1;
	}
	return fail;
}

void signal_handler(int sig)
{
	reset();
	done();
	exit(sig<<8);
}

// SVF reader

int current_state = IDLE;
void go_to_state(int new_state)
{
	if(new_state == current_state)
		return;
	switch(new_state) {
	case RESET:
		statewalk(0x1F, 5, 0);
		break;
	case IDLE:
		switch(current_state) {
		case RESET:
			statewalk(0x00, 1, 0);
			break;
		case DRPAUSE:
			statewalk(0x03, 3, 0);
			break;
		default:
			fprintf(stderr, "I don't know how to get from %s to %s\n", states[current_state], states[new_state]);
			exit(1);
		}
		break;
	case DRSHIFT:
		switch(current_state) {
		case RESET:
			statewalk(0x02, 4, 0);
			break;
		case IDLE:
			statewalk(0x01, 3, 0);
			break;
		default:
			fprintf(stderr, "I don't know how to get from %s to %s\n", states[current_state], states[new_state]);
			exit(1);
		}
		break;
	case IRSHIFT:
		switch(current_state) {
		case RESET:
			statewalk(0x06, 5, 0);
			break;
		case IDLE:
			statewalk(0x03, 4, 0);
			break;
		default:
			fprintf(stderr, "I don't know how to get from %s to %s\n", states[current_state], states[new_state]);
			exit(1);
		}
		break;
	default:
		fprintf(stderr, "I don't know how to get to %s\n", states[new_state]);
		exit(1);
	}
	current_state = new_state;
}

void run_test(int cycles, int run_state)
{
	uint8_t buf[256];
	int p = 0, a;
	memset(buf, 0, 256);
	go_to_state(run_state);
	if(cycles >= 8) {
		a = (cycles/8)-1;
		buf[p++] = MPSSE_WRITE_NEG|MPSSE_DO_WRITE|MPSSE_LSB;
		buf[p++] = a;
		buf[p++] = a>>8;
		p += a+1;
		cycles %= 8;
	}
	if(cycles) {
		buf[p++] = MPSSE_BITMODE|MPSSE_WRITE_NEG|MPSSE_DO_WRITE|MPSSE_LSB;
		buf[p++] = cycles-1;
		p++;
	}
	if(ftdi_write_data(&ctx, buf, p)<0)
		fprintf(stderr, "write error\n");
	current_state = run_state;
}

int get_bit(char *buf, int index, int zero, int max, int def)
{
	int ch;
	if(index < zero)
		return def;
	if(index >= max)
		return def;
	ch = buf[index>>2];
	if(ch >= '0' && ch <= '9')
		ch -= '0';
	else if(ch >= 'A' && ch <= 'F')
		ch -= 'A'-10;
	else if(ch >= 'a' && ch <= 'f')
		ch -= 'a'-10;
	else {
		fprintf(stderr, "Invalid character '%c' in a hex string.\n", ch);
		exit(1);
	}
	return (ch>>((index&3)^3))&1;
}

int shift_reg_int(int zero, int base, int len, int l, char *tdi, char *tdo_val, char *tdo_msk, int end_walk, int fill)
{
	int t = (end_walk!=-1);
	uint8_t buf[4096], fl=tdo_val?MPSSE_DO_READ:0;
	uint32_t p=0, i, ol = l, ib = 0, to = 0, r, vp = 0, j, a, vl, om = 1, ov;
	// prepare and send TDI/TMS message
	if((l-t)>8) {
		buf[p++] = MPSSE_DO_WRITE|fl|MPSSE_LSB|MPSSE_WRITE_NEG;
		vl = ((l-t)/8)-1;
		buf[p++] = vl;
		buf[p++] = vl>>8;
		for(i=0;i<=vl;i++) {
			a = 0;
			for(j=0;j<8;j++) {
				ov = get_bit(tdi, base-(vp+j), zero, len, fill);
				a |= ov<<j;
			}
			buf[p] = a;
			vp += 8;
			l -= 8;
			p++;
			ib++;
		}
	}
	if((l-t)>=1) {
		if((l-t)>8) {
			fprintf(stderr, "Internal fault\n");
			exit(1);
		}
		buf[p] = MPSSE_DO_WRITE|fl|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = l-t-1;
		a = 0;
		for(j=0;j<l-t;j++) {
			ov = get_bit(tdi, base-(vp+j), zero, len, fill);
			a |= ov<<j;
		}
		buf[p+2] = a;
		vp += l-t;
		l = t;
		p += 3;
		ib++;
	}
	if(l) {
		buf[p] = MPSSE_WRITE_TMS|fl|MPSSE_LSB|MPSSE_BITMODE|MPSSE_WRITE_NEG;
		buf[p+1] = (end_walk>>8)-1;
		ov = get_bit(tdi, base-vp, zero, len, fill);
		buf[p+2] = (ov<<7)|end_walk;
		p += 3;
		ib++;
	}
	if(tdo_val)
		buf[p++] = SEND_IMMEDIATE;
	if(ftdi_write_data(&ctx, buf, p)<0) {
		fprintf(stderr, "write error (%s)\n", ftdi_get_error_string(&ctx));
		return 1;
	}
	// skip if nothing to be read
	if(!tdo_val)
		return 0;
	// read, unpack and compare TDO message
	p = 0;
	do {
		if((r=ftdi_read_data(&ctx, buf+p, ib-p))<0) {
			fprintf(stderr, "read error\n");
			return 1;
		}
		p += r;
		if(to>10) {
			fprintf(stderr, "read timeout\n");
			return 1;
		}
		to++;
	} while(p<ib);
	p = 0;
	l = ol;
	vp = 0;
	while((l-t)>8) {
		for(j=0;j<8;j++) {
			ib = (buf[p]>>j)&1;
#ifdef DEBUG
			if(base-(vp+j)>=zero && base-(vp+j)<len)
				fprintf(stderr, "%d", ib);
#endif
			ov = get_bit(tdo_val, base-(vp+j), zero, len, 0);
			if(tdo_msk)
				om = get_bit(tdo_msk, base-(vp+j), zero, len, 0);
			if(om && (ib != ov)) {
				fprintf(stderr, "Vector compare failed.\n");
				return 1;
			}
		}
		vp += 8;
		l -= 8;
		p++;
	}
	if((l-t) >= 1) {
		for(j=0;j<l-t;j++) {
			ib = (buf[p]>>(j+8-(l-t)))&1;
#ifdef DEBUG
			if(base-(vp+j)>=zero && base-(vp+j)<len)
				fprintf(stderr, "%d", ib);
#endif
			ov = get_bit(tdo_val, base-(vp+j), zero, len, 0);
			if(tdo_msk)
				om = get_bit(tdo_msk, base-(vp+j), zero, len, 0);
			if(om && (ib != ov)) {
				fprintf(stderr, "Vector compare failed.\n");
				return 1;
			}
		}
		vp += l-t;
		p++;
	}
	if(t) {
		ib = buf[p]>>7;
#ifdef DEBUG
		if(base-vp>=zero && base-vp<len)
			fprintf(stderr, "%d", ib);
#endif
		ov = get_bit(tdo_val, base-vp, zero, len, 0);
		if(tdo_msk)
			om = get_bit(tdo_msk, base-vp, zero, len, 0);
		if(om && (ib != ov)) {
			fprintf(stderr, "Vector compare failed.\n");
			return 1;
		}
	}
#ifdef DEBUG
	fprintf(stderr, "\n");
#endif
	return 0;
}

int left_ir, right_ir;
int left_dr, right_dr;

int shift_reg(int reg, int len, char *tdi, char *tdo_val, char *tdo_msk, int end_state, int fill, int align32)
{
	// hex buffers are byte-aligned
	int left = reg?left_ir:left_dr, right = reg?right_ir:right_dr;
	int base = len + right, bsize, end_walk, delta = (8-(len&7))&7;
	int remaining = len + right + left, rcorr = 0;
	if(align32) {
		rcorr = -(left+right);
		while(rcorr<0)
			rcorr += 32;
		right += rcorr;
		base = len + right;
		remaining = len + right + left;
	}
	if(reg) {
		switch(end_state) {
		case IDLE:
			end_walk = 0x303;
			break;
		default:
			fprintf(stderr, "I can't terminate an IR write in %s.\n", states[end_state]);
			exit(1);
		}
	} else {
		switch(end_state) {
		case IDLE:
			end_walk = 0x303;
			break;
		case DRPAUSE:
			end_walk = 0x201;
			break;
		default:
			fprintf(stderr, "I can't terminate a DR write in %s.\n", states[end_state]);
			exit(1);
		}
	}
	go_to_state(reg?IRSHIFT:DRSHIFT);
	while(remaining>0) {
		bsize = MAXBITS;
		if(bsize > remaining)
			bsize = remaining;
		if(shift_reg_int(delta, base+delta-1, len+delta, bsize, tdi, tdo_val, tdo_msk, (bsize==remaining)?end_walk:-1, fill))
			return 1;
		base -= bsize;
		remaining -= bsize;
	}
	current_state = end_state;
	return 0;
}

void map_lr(int idx)
{
	int i;
	right_dr = idx;
	left_dr = ndev-idx-1;
	left_ir = right_ir = 0;
	for(i=0; i<ndev; i++) {
		if(i<idx)
			right_ir += irlen[i];
		if(i>idx)
			left_ir += irlen[i];
	}
}

char *words[NWORDS];
int wlen[NWORDS], wmaxlen[NWORDS];
int nwords;
int state_to_id(char *name)
{
	int i;
	for(i=0;states[i];i++)
		if(!strcasecmp(name, states[i]))
			return i;
	fprintf(stderr, "Bad SVF: State '%s' unknown.\n", name);
	exit(1);
}

int enddr_state = IDLE, endir_state = IDLE;
char *tdi, *tdo_val, *tdo_msk[2];
void end_line(void)
{
	int i, a, align32;
#ifdef DEBUG
	for(i=0;i<nwords;i++)
		if(wlen[i]>64)
			fprintf(stderr, " *");
		else
			fprintf(stderr, " %s",words[i]);
	fprintf(stderr, "\n");
#endif
	if(!strcasecmp(words[0], "STATE")) {
		for(i=1;i<nwords;i++)
			go_to_state(state_to_id(words[i]));
	} else if(!strcasecmp(words[0], "SDR") || !strcasecmp(words[0], "SIR")) {
		a=!strcasecmp(words[0], "SIR");
		tdi = NULL;
		tdo_val = NULL;
		i = 2;
		align32 = 0;
		while(i<nwords) {
			if(!strcasecmp(words[i], "TDI")) {
				i++;
				tdi = words[i]+1;
			} else if(!strcasecmp(words[i], "TDO")) {
				i++;
				tdo_val = words[i]+1;
			} else if(!strcasecmp(words[i], "ALIGN")) {
				align32 = 1;
			} else if(!strcasecmp(words[i], "MASK")) {
				i++;
				if(tdo_msk[a])
					free(tdo_msk[a]);
				tdo_msk[a] = strdup(words[i]+1);
			} else if(!strcasecmp(words[i], "SMASK")) {
				i++;
		} else {
				fprintf(stderr, "Bad SVF: Unknown key '%s' used in '%s'.\n", words[i], words[0]);
				exit(1);
			}
			i++;
		}
		if(shift_reg(a, atoi(words[1]), tdi, tdo_val, tdo_msk[a], a?endir_state:enddr_state, a, align32)) {
			reset();
			done();
			exit(1);
		}
	} else if(!strcasecmp(words[0], "RUNTEST")) {
		if(nwords!=3 || strcmp(words[2], "TCK")) {
			fprintf(stderr, "Bad SVF: Unsupported form of 'RUNTEST'.\n");
			exit(1);
		}
		run_test(atoi(words[1]), IDLE);
	} else if(!strcasecmp(words[0], "ENDDR") || !strcasecmp(words[0], "ENDIR")) {
		i = state_to_id(words[1]);
		if(i!=IDLE && i!=DRPAUSE) {
			fprintf(stderr, "Bad SVF: State '%s' not a valid '%s' state.\n", words[1], words[0]);
			exit(1);
		}
		if(!strcasecmp(words[0], "ENDDR"))
			enddr_state = i;
		else
			endir_state = i;
	} else if(!strcasecmp(words[0], "HDR") || !strcasecmp(words[0], "HIR") ||
		  !strcasecmp(words[0], "TDR") || !strcasecmp(words[0], "TIR")) {
		if(strcasecmp(words[1], "0")) {
			fprintf(stderr, "Bad SVF: '%s' has to be '0' (verify that there is only one device in iMPACT chain).\n", words[0]);
			exit(1);
		}
	} else if(!strcasecmp(words[0], "TRST")) {
		if(strcasecmp(words[1], "OFF")) {
			fprintf(stderr, "Bad SVF: 'TRST' has to be 'OFF'.\n");
			exit(1);
		}
	} else if(!strcasecmp(words[0], "FREQUENCY")) {
		// no-op
	} else {
		fprintf(stderr, "Unknown instruction '%s'.\n", words[0]);
		exit(1);
	}
	while(nwords>0) {
		nwords--;
		wlen[nwords]=0;
	}
}

void add_char(int word, char ch)
{
	if(wlen[word]>=wmaxlen[word]-1) {
		if(!wmaxlen[word])
			wmaxlen[word] = CHUNK;
		else
			wmaxlen[word] *= 2;
		words[word] = realloc(words[word], wmaxlen[word]);
	}
	words[word][wlen[word]++] = ch;
}

int in_paren;
void run_char(char ch)
{
	if(wlen[nwords]) {
		if(ch!=' ' && ch!='\t' && ch!='\n' && ch!=';') {
			if(ch == '(')
				in_paren = 1;
			else if(ch == ')')
				in_paren = 0;
			add_char(nwords, ch);
		} else if(!in_paren) {
			add_char(nwords, 0);
			nwords++;
			if(ch==';')
				end_line();
			if(nwords>=NWORDS) {
				fprintf(stderr, "Too many words in a line ('%s').\n", words[0]);
				exit(1);
			}
		}
	} else {
		if(ch!=' ' && ch!='\t' && ch!='\n' && ch!=';') {
			if(ch == '(')
				in_paren = 1;
			else if(ch == ')')
				in_paren = 0;
			add_char(nwords, ch);
		} else if(ch==';') {
			end_line();
		}
	}
}

void run_svf(char *fn)
{
	char buf[CHUNK];
	int len, i, comment=0;
	FILE *f = fopen(fn, "r");
	if(!f) {
		fprintf(stderr, "File '%s' not found.\n", fn);
		exit(1);
	}
	do {
		len = fread(buf, 1, CHUNK, f);
		for(i=0; i<len; i++) {
			switch(comment) {
			case 0:
				if(buf[i] == '/')
					comment = 1;
				else
					run_char(buf[i]);
				break;
			case 1:
				if(buf[i] == '/')
					comment = 2;
				else {
					comment = 0;
					run_char('/');
					run_char(buf[i]);
				}
				break;
			case 2:
				if(buf[i] == '\n') {
					comment = 0;
					run_char('\n');
				}
			}
		}
	} while(len == CHUNK);
	fclose(f);
}

int main(int argc, char *argv[])
{
	int i, idx, firstarg=1;
	char *p;
	if(argc<2) {
		printf("usage: %s [B:boardname] <dev#>:<file.svf> [...]\n", argv[0]);
		return 1;
	}
	if(argv[1][0]=='B') {
		if(argc<3) {
			printf("usage: %s [B:boardname] <dev#>:<file.svf> [...]\n", argv[0]);
			return 1;
		}
		firstarg = 2;
		strncpy(board_name, argv[1]+2, 8);
	}
	if(init()) {
		fprintf(stderr, "Board not found\n");
		return 1;
	}
	signal(SIGINT, signal_handler);
	signal(SIGSEGV, signal_handler);
	signal(SIGTERM, signal_handler);
	reset();
	if(size_chain()) {
		fprintf(stderr, "Chain sizing failed\n");
		reset();
		done();
		return 1;
	}
	fprintf(stderr, "Found %d devices with total IR length of %d\n", ndev, total_ir);
	if(idcodes()) {
		fprintf(stderr, "Missing device information\n");
		reset();
		done();
		return 1;
	}
	reset();
	for(i=firstarg;i<argc;i++) {
		idx = strtol(argv[i], &p, 0);
		if(*p!=':') {
			fprintf(stderr, "Malformed argument: '%s'\n", argv[i]);
			return 1;
		}
		p++;
		fprintf(stderr, "Loading device %d[%s] with '%s'...\n", idx, name[idx], p);
		map_lr(idx);
		run_svf(p);
		reset();
	}
	done();
	return 0;
}
