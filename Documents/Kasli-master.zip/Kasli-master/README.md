# Kasli
Kasli is low-cost FPGA carrier, capable of controlling at 12 Eurocard extension modules. It can act as either an ARTIQ central core device, or as a satellite connected to the master via DRTIO.

## Design Files

Design files (schematics, PCB layouts, BOMs) can be found at [Kasli/Releases](https://github.com/sinara-hw/Kasli/releases).

## Wiki

More information can be found on the [wiki](https://github.com/sinara-hw/Kasli/wiki).
